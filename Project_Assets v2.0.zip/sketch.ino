// ─── PINOS ──────────────────────────────────────────────────
#define LED_VERMELHO 2
#define LED_AMARELO  4
#define LED_VERDE    5
#define BUZZER       25
#define SENSOR       34
#define BOTAO        27

// ─── LIMIARES DE GÁS (com histerese) ───────────────────────
#define SEGURO_SUBIDA   1500   // entra em ALERTA  acima desse valor
#define SEGURO_DESCIDA  1350   // volta ao SEGURO  abaixo desse valor
#define PERIGO_SUBIDA   2800   // entra em PERIGO  acima desse valor
#define PERIGO_DESCIDA  2600   // volta ao ALERTA  abaixo desse valor

// ─── CONFIGURAÇÕES DE TEMPO ─────────────────────────────────
#define DEBOUNCE_MS        300   // tempo mínimo entre dois cliques do botão
#define PERIODO_LEITURA   2000   // lê o sensor a cada 2 segundos
#define TIMEOUT_SENSOR    6000   // se ficar 6 s sem leitura válida → erro de sensor

// ─── CONFIGURAÇÕES DO LOG ───────────────────────────────────
#define LOG_MAX_ENTRADAS  10     // guarda os últimos 10 eventos na memória

// ============================================================
//  ENUM DE ESTADOS — declarado antes de tudo pois outras
//  funções abaixo precisam conhecer esse tipo
// ============================================================
enum Estado {
  DESLIGADO,     // tudo apagado, aguardando botão
  SEGURO,        // LED verde — gás baixo
  ALERTA,        // LED amarelo — gás médio
  PERIGO,        // LED vermelho + buzzer — gás alto
  FALHA_SENSOR,  // sensor parou de responder
  FALHA_PINO     // pino do sensor com leitura impossível
};

// ============================================================
//  PROTÓTIPOS — "aviso antecipado" ao compilador
//  Em C++ a função precisa ser conhecida antes de ser usada.
//  Aqui declaramos as assinaturas; as definições vêm depois.
// ============================================================
const char* nomeEstado(Estado e);
void mudarEstado(Estado novo, const char* motivo);
void verificarContagemErros();
void verificarTimeoutSensor(unsigned long agora);
void apagarTudo();
void aplicarSaidas();
void publicarPayload(int gasMedia);

// ============================================================
//  SISTEMA DE LOG
//  O log guarda os últimos eventos em uma lista circular.
//  Quando a lista enche, a entrada mais antiga é substituída.
// ============================================================

// Esses são os "níveis" do log — igual ao que você vê em
// aplicativos: INFO = informação normal, WARN = atenção,
// ERROR = algo deu errado.
enum NivelLog { INFO, WARN, ERROR_LOG };

// Essa é a estrutura de uma entrada no log.
// Pensa como uma linha de uma tabela: cada linha tem timestamp,
// nível e mensagem.
struct EntradaLog {
  unsigned long timestamp;   // quando aconteceu (em ms desde o boot)
  NivelLog nivel;            // INFO / WARN / ERROR
  char mensagem[60];         // o texto do evento
};

// O buffer circular: uma lista de 10 entradas.
EntradaLog bufferLog[LOG_MAX_ENTRADAS];
int logIdx   = 0;    // onde vai a próxima entrada
int logTotal = 0;    // quantas entradas foram registradas até agora

// ── Função: registrar um evento no log ──────────────────────
// Como usar:  registrarLog(INFO,  "Sistema ligado");
//             registrarLog(WARN,  "Leitura alta: 2750");
//             registrarLog(ERROR_LOG, "Sensor sem resposta");
void registrarLog(NivelLog nivel, const char* mensagem) {

  // Salva no buffer circular
  bufferLog[logIdx].timestamp = millis();
  bufferLog[logIdx].nivel     = nivel;
  strncpy(bufferLog[logIdx].mensagem, mensagem, 59);
  logIdx = (logIdx + 1) % LOG_MAX_ENTRADAS;  // avança, volta ao 0 quando chega em 10
  logTotal++;

  // Monta e imprime no Serial Monitor ao mesmo tempo
  // Formato: [1234ms] [WARN] Mensagem aqui
  Serial.print("[");
  Serial.print(millis());
  Serial.print("ms] [");

  if      (nivel == INFO)      Serial.print("INFO ");
  else if (nivel == WARN)      Serial.print("WARN ");
  else                         Serial.print("ERROR");

  Serial.print("] ");
  Serial.println(mensagem);
}

// ── Função: imprimir todo o histórico do log ────────────────
// Chame essa função quando quiser ver os últimos eventos
// (por exemplo, ao pressionar o botão por 3 segundos no físico)
void imprimirHistoricoLog() {
  Serial.println("========== HISTORICO DE LOG ==========");
  int n = (logTotal < LOG_MAX_ENTRADAS) ? logTotal : LOG_MAX_ENTRADAS;
  for (int i = 0; i < n; i++) {
    // Calcula qual entrada vem primeiro (a mais antiga)
    int idx = (logIdx - n + i + LOG_MAX_ENTRADAS) % LOG_MAX_ENTRADAS;
    Serial.print("[");
    Serial.print(bufferLog[idx].timestamp);
    Serial.print("ms] [");
    if      (bufferLog[idx].nivel == INFO)      Serial.print("INFO ");
    else if (bufferLog[idx].nivel == WARN)      Serial.print("WARN ");
    else                                        Serial.print("ERROR");
    Serial.print("] ");
    Serial.println(bufferLog[idx].mensagem);
  }
  Serial.println("======================================");
}

// ============================================================
//  MÁQUINA DE ESTADOS (FSM)
//  O sistema sempre está em UM desses estados.
//  Ele muda de estado conforme as leituras e eventos.
// ============================================================
Estado estadoAtual    = DESLIGADO;
Estado estadoAnterior = DESLIGADO;

// ============================================================
//  VARIÁVEIS DE CONTROLE
// ============================================================
volatile bool          ligado           = false;
volatile bool          botaoEvento      = false;
volatile unsigned long ultimoBotao      = 0;

unsigned long ultimaLeitura    = 0;   // quando foi a última leitura do sensor
unsigned long ultimaSaidaMs    = 0;   // quando foi a última atualização dos LEDs
unsigned long ultimoSensorOk   = 0;   // quando o sensor respondeu pela última vez
int           leituraAtual     = 0;   // valor lido do sensor agora
int           contagemErros    = 0;   // quantos erros seguidos aconteceram

// ── Média móvel (suaviza leituras instáveis) ────────────────
// Em vez de usar só a leitura atual, usamos a média das últimas
// 5 leituras. Isso evita que um pico aleatório dispare o alarme.
#define JANELA_MEDIA 5
int bufferMedia[JANELA_MEDIA] = {0, 0, 0, 0, 0};
int idxMedia = 0;

int calcularMedia(int novaLeitura) {
  bufferMedia[idxMedia] = novaLeitura;
  idxMedia = (idxMedia + 1) % JANELA_MEDIA;
  long soma = 0;
  for (int i = 0; i < JANELA_MEDIA; i++) soma += bufferMedia[i];
  return soma / JANELA_MEDIA;
}

// ============================================================
//  TRATAMENTO DE ERROS E EXCEÇÕES
//  Cada função abaixo cuida de um tipo diferente de problema.
// ============================================================

// ── Erro 1: Leitura fora de faixa ───────────────────────────
// O ADC do ESP32 só pode retornar valores entre 0 e 4095.
// Se vier algo diferente, o hardware ou o pino está com problema.
bool verificarFaixaSensor(int valor) {
  if (valor < 0 || valor > 4095) {
    char msg[60];
    sprintf(msg, "Leitura impossivel: %d (fora de 0-4095)", valor);
    registrarLog(ERROR_LOG, msg);
    contagemErros++;
    return false;   // false = leitura inválida
  }
  return true;      // true = leitura válida
}

// ── Erro 2: Sensor desconectado (timeout) ───────────────────
// Se o sensor ficar muito tempo sem dar uma leitura válida,
// provavelmente ele foi desconectado ou queimou.
// Solução: entrar no estado FALHA_SENSOR para avisar o operador.
void verificarTimeoutSensor(unsigned long agora) {
  if (estadoAtual == FALHA_SENSOR || estadoAtual == DESLIGADO) return;

  if (agora - ultimoSensorOk >= TIMEOUT_SENSOR) {
    char msg[60];
    sprintf(msg, "Sensor sem resposta por %lu ms", agora - ultimoSensorOk);
    registrarLog(ERROR_LOG, msg);
    mudarEstado(FALHA_SENSOR, "timeout_sensor");
  }
}

// ── Erro 3: Muitos erros seguidos ───────────────────────────
// Se acontecerem 5 erros em sequência, algo está seriamente errado.
// O sistema entra em FALHA_PINO para alertar que precisa de manutenção.
void verificarContagemErros() {
  if (contagemErros >= 5) {
    registrarLog(ERROR_LOG, "5+ erros seguidos — possivel falha de hardware");
    mudarEstado(FALHA_PINO, "multiplos_erros");
    contagemErros = 0;  // zera para não ficar repetindo
  }
}

// ── Erro 4: Pino de LED preso (verificação de sanidade) ─────
// Verifica se o pino responde ao que mandamos.
// Isso detecta LEDs queimados ou pinos com defeito.
// Nota: no Wokwi sempre vai passar; útil no físico.
bool verificarPinoSaida(int pino, const char* nomePino) {
  digitalWrite(pino, HIGH);
  delayMicroseconds(50);
  int lido = digitalRead(pino);
  if (lido != HIGH) {
    char msg[60];
    sprintf(msg, "Pino %s (%d) nao responde corretamente", nomePino, pino);
    registrarLog(WARN, msg);
    return false;
  }
  digitalWrite(pino, LOW);  // deixa LOW depois do teste
  return true;
}

// ============================================================
//  FUNÇÃO DE MUDANÇA DE ESTADO
//  Centraliza todas as transições — facilita depuração.
//  Toda vez que o estado muda, registra no log automaticamente.
// ============================================================
const char* nomeEstado(Estado e) {
  switch (e) {
    case DESLIGADO:    return "DESLIGADO";
    case SEGURO:       return "SEGURO";
    case ALERTA:       return "ALERTA";
    case PERIGO:       return "PERIGO";
    case FALHA_SENSOR: return "FALHA_SENSOR";
    case FALHA_PINO:   return "FALHA_PINO";
    default:           return "DESCONHECIDO";
  }
}

void mudarEstado(Estado novo, const char* motivo) {
  if (novo == estadoAtual) return;  // não faz nada se já está nesse estado

  // Monta mensagem de log: "SEGURO -> ALERTA [motivo: leitura_alta]"
  char msg[60];
  sprintf(msg, "%s -> %s [%s]", nomeEstado(estadoAtual), nomeEstado(novo), motivo);

  // Define o nível do log conforme o estado de destino
  NivelLog nivel = INFO;
  if (novo == ALERTA)                          nivel = WARN;
  if (novo == PERIGO || novo == FALHA_SENSOR || novo == FALHA_PINO) nivel = ERROR_LOG;

  registrarLog(nivel, msg);

  estadoAnterior = estadoAtual;
  estadoAtual    = novo;
}

// ============================================================
//  INTERRUPÇÃO DO BOTÃO
//  Essa função é chamada automaticamente pelo ESP32 quando o
//  botão é pressionado. É rápida e só seta um flag (botaoEvento).
// ============================================================
void IRAM_ATTR botaoPressionado() {
  unsigned long agora = millis();
  if (agora - ultimoBotao > DEBOUNCE_MS) {
    botaoEvento = true;    // avisa o loop principal
    ultimoBotao = agora;
  }
}

// ============================================================
//  PROCESSAR BOTÃO (chamado no loop principal)
//  Decide o que fazer conforme o estado atual.
// ============================================================
void processarBotao() {
  botaoEvento = false;  // consome o evento

  if (!ligado) {
    // Sistema estava desligado: ligar
    ligado = true;
    ultimoSensorOk = millis();  // reseta o timer do sensor
    contagemErros  = 0;
    mudarEstado(SEGURO, "botao_liga");

  } else if (estadoAtual == PERIGO) {
    // Em perigo: botão silencia e desliga
    ligado = false;
    mudarEstado(DESLIGADO, "botao_silencia_alarme");
    apagarTudo();

  } else {
    // Em qualquer outro estado: desligar normalmente
    ligado = false;
    mudarEstado(DESLIGADO, "botao_desliga");
    apagarTudo();
  }

  // Imprime o histórico completo quando desligar — útil para depuração
  if (!ligado) {
    imprimirHistoricoLog();
  }
}

// ============================================================
//  FUNÇÕES DE SAÍDA (LEDs e buzzer)
// ============================================================
void apagarTudo() {
  digitalWrite(LED_VERDE,    LOW);
  digitalWrite(LED_AMARELO,  LOW);
  digitalWrite(LED_VERMELHO, LOW);
  noTone(BUZZER);
}

void aplicarSaidas() {
  switch (estadoAtual) {

    case SEGURO:
      digitalWrite(LED_VERDE,    HIGH);
      digitalWrite(LED_AMARELO,  LOW);
      digitalWrite(LED_VERMELHO, LOW);
      noTone(BUZZER);
      break;

    case ALERTA:
      digitalWrite(LED_VERDE,    LOW);
      digitalWrite(LED_AMARELO,  HIGH);
      digitalWrite(LED_VERMELHO, LOW);
      noTone(BUZZER);
      break;

    case PERIGO:
      digitalWrite(LED_VERDE,    LOW);
      digitalWrite(LED_AMARELO,  LOW);
      digitalWrite(LED_VERMELHO, HIGH);
      tone(BUZZER, 1250);
      break;

    case FALHA_SENSOR:
      // Pisca vermelho e amarelo alternados — sinal de erro de sensor
      {
        static unsigned long tPisca = 0;
        static bool flag = false;
        if (millis() - tPisca > 600) {
          tPisca = millis();
          flag = !flag;
          digitalWrite(LED_VERMELHO, flag);
          digitalWrite(LED_AMARELO, !flag);
          digitalWrite(LED_VERDE, LOW);
          if (flag) tone(BUZZER, 500);
          else      noTone(BUZZER);
        }
      }
      break;

    case FALHA_PINO:
      // Todos os LEDs piscam juntos — sinal de erro de hardware
      {
        static unsigned long tPisca2 = 0;
        static bool flag2 = false;
        if (millis() - tPisca2 > 300) {
          tPisca2 = millis();
          flag2 = !flag2;
          digitalWrite(LED_VERMELHO, flag2);
          digitalWrite(LED_AMARELO,  flag2);
          digitalWrite(LED_VERDE,    flag2);
          if (flag2) tone(BUZZER, 800);
          else       noTone(BUZZER);
        }
      }
      break;

    case DESLIGADO:
    default:
      apagarTudo();
      break;
  }
}

// ============================================================
//  PUBLICAR PAYLOAD JSON
//  Envia os dados atuais pelo Serial no formato JSON.
//  Um gateway (Raspberry Pi, Node-RED) pode ler isso e guardar.
// ============================================================
void publicarPayload(int gasMedia) {
  Serial.print("{\"device_id\":\"gas_sensor_01\"");
  Serial.print(",\"ts\":"); Serial.print(millis());
  Serial.print(",\"estado\":\""); Serial.print(nomeEstado(estadoAtual)); Serial.print("\"");
  Serial.print(",\"gas_raw\":"); Serial.print(leituraAtual);
  Serial.print(",\"gas_avg\":"); Serial.print(gasMedia);
  Serial.print(",\"erros\":"); Serial.print(contagemErros);
  Serial.println("}");
}

// ============================================================
//  SETUP — roda UMA VEZ ao ligar
// ============================================================
void setup() {
  Serial.begin(115200);
  registrarLog(INFO, "Iniciando sistema...");

  // Configura pinos de saída
  pinMode(LED_VERMELHO, OUTPUT);
  pinMode(LED_AMARELO,  OUTPUT);
  pinMode(LED_VERDE,    OUTPUT);

  // Configura botão com resistor interno (INPUT_PULLUP)
  // Significa: pino fica HIGH quando solto, LOW quando pressionado
  pinMode(BOTAO, INPUT_PULLUP);

  // Liga a interrupção do botão
  attachInterrupt(digitalPinToInterrupt(BOTAO), botaoPressionado, FALLING);

  randomSeed(analogRead(0));
  apagarTudo();

  // ── Verificação de sanidade dos pinos de saída ──────────
  // Testa cada LED antes de começar — detecta pinos com defeito
  registrarLog(INFO, "Verificando pinos de saida...");
  bool ok = true;
  ok &= verificarPinoSaida(LED_VERDE,    "LED_VERDE");
  ok &= verificarPinoSaida(LED_AMARELO,  "LED_AMARELO");
  ok &= verificarPinoSaida(LED_VERMELHO, "LED_VERMELHO");

  if (ok) registrarLog(INFO, "Pinos OK");
  else    registrarLog(WARN, "Um ou mais pinos com problema");

  registrarLog(INFO, "Sistema pronto. Pressione o botao para ligar.");
}

// ============================================================
//  LOOP — roda CONTINUAMENTE
//  Usa millis() em vez de delay() para não travar o sistema.
//  Isso é chamado "non-blocking" — o loop nunca para.
// ============================================================
void loop() {
  unsigned long agora = millis();

  // ── 1. Verificar botão ─────────────────────────────────
  if (botaoEvento) {
    processarBotao();
  }

  // ── 2. Se desligado, não faz mais nada ─────────────────
  if (!ligado || estadoAtual == DESLIGADO) {
    apagarTudo();
    return;
  }

  // ── 3. Leitura do sensor a cada PERIODO_LEITURA ms ─────
  if (agora - ultimaLeitura >= PERIODO_LEITURA) {
    ultimaLeitura = agora;

    // Simula leitura do sensor (no Wokwi usa random;
    // no físico troque por: leituraAtual = analogRead(SENSOR); )
    leituraAtual = random(0, 4096);

    // ── Verificação 1: valor dentro da faixa? ──────────
    if (!verificarFaixaSensor(leituraAtual)) {
      verificarContagemErros();  // acumula erros; se muitos → FALHA_PINO
      return;                    // descarta esta leitura e espera a próxima
    }

    // Se chegou aqui, a leitura é válida
    contagemErros  = 0;          // zera contagem de erros consecutivos
    ultimoSensorOk = agora;      // atualiza o timer do sensor

    // Calcula média móvel (suaviza ruído)
    int gasMedia = calcularMedia(leituraAtual);

    // ── Log de leitura (WARN se perto do limiar) ───────
    if (gasMedia >= PERIGO_SUBIDA) {
      char msg[60];
      sprintf(msg, "Leitura ALTA: raw=%d avg=%d", leituraAtual, gasMedia);
      registrarLog(WARN, msg);
    } else if (gasMedia >= SEGURO_SUBIDA) {
      char msg[60];
      sprintf(msg, "Leitura MEDIA: raw=%d avg=%d", leituraAtual, gasMedia);
      registrarLog(INFO, msg);
    }

    // ── Transições de estado com HISTERESE ─────────────
    switch (estadoAtual) {
      case SEGURO:
        if      (gasMedia >= PERIGO_SUBIDA)  mudarEstado(PERIGO,  "leitura_alta");
        else if (gasMedia >= SEGURO_SUBIDA)  mudarEstado(ALERTA,  "leitura_media");
        break;

      case ALERTA:
        if      (gasMedia >= PERIGO_SUBIDA)  mudarEstado(PERIGO,  "leitura_alta");
        else if (gasMedia <  SEGURO_DESCIDA) mudarEstado(SEGURO,  "leitura_baixou");
        break;

      case PERIGO:
        if (gasMedia < PERIGO_DESCIDA)       mudarEstado(ALERTA,  "leitura_caiu");
        break;

      case FALHA_SENSOR:
        // Se o sensor voltou a responder, retorna ao SEGURO
        mudarEstado(SEGURO, "sensor_recuperado");
        break;

      default:
        break;
    }

    // Envia payload JSON pelo Serial
    publicarPayload(gasMedia);
  }

  // ── 4. Verificar timeout do sensor ────────────────────
  // Roda fora do bloco de leitura para funcionar mesmo se
  // a leitura travar ou for descartada
  verificarTimeoutSensor(agora);

  // ── 5. Atualizar LEDs e buzzer ────────────────────────
  aplicarSaidas();
}
