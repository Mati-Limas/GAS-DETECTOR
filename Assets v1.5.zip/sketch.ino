#define LED_VERMELHO 2
#define LED_AMARELO 4
#define LED_VERDE 5
#define BUZZER 25
#define SENSOR 34
#define BOTAO 27

#define SEGURO 1500
#define ALERTA 2800
#define DEBOUNCE_MS 300

int leituraGas = 0;
volatile bool ligado = true;
volatile bool interrompido = false;
volatile unsigned long ultimoPressionado = 0;

void IRAM_ATTR botaoPressionado() {
  unsigned long agora = millis();
  if (agora - ultimoPressionado > DEBOUNCE_MS) {
    ligado = !ligado;
    interrompido = true;
    ultimoPressionado = agora;
  }
}

void setup() {
  pinMode(LED_VERMELHO, OUTPUT);
  pinMode(LED_AMARELO, OUTPUT);
  pinMode(LED_VERDE, OUTPUT);
  pinMode(BOTAO, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(BOTAO), botaoPressionado, FALLING);

  Serial.begin(115200);
  randomSeed(analogRead(0));
}

void nivelSeguro() {
  digitalWrite(LED_VERDE, HIGH);
  digitalWrite(LED_AMARELO, LOW);
  digitalWrite(LED_VERMELHO, LOW);
  noTone(BUZZER);
}

void nivelAlerta() {
  digitalWrite(LED_VERDE, LOW);
  digitalWrite(LED_AMARELO, HIGH);
  digitalWrite(LED_VERMELHO, LOW);
  noTone(BUZZER);
}

bool delayInterrompivel(unsigned long ms) {
  unsigned long inicio = millis();
  while (millis() - inicio < ms) {
    if (interrompido) return true;
    delayMicroseconds(100);
  }
  return false;
}

void nivelPerigo() {
  digitalWrite(LED_VERDE, LOW);
  digitalWrite(LED_AMARELO, LOW);
  digitalWrite(LED_VERMELHO, HIGH);

  Serial.println("⚠ PERIGO! Pressione o botão para parar o alarme.");

  for (int i = 0; i < 5; i++) {
    if (interrompido) break;

    tone(BUZZER, 1250);
    if (delayInterrompivel(400)) break;

    noTone(BUZZER);
    if (delayInterrompivel(280)) break;
  }

  noTone(BUZZER);
}

void desligarTudo() {
  digitalWrite(LED_VERDE, LOW);
  digitalWrite(LED_AMARELO, LOW);
  digitalWrite(LED_VERMELHO, LOW);
  noTone(BUZZER);
}

void loop() {

  interrompido = false;

  if (!ligado) {
    desligarTudo();
    Serial.println("Dispositivo DESLIGADO. Pressione o botão para ligar.");
    delay(2000);
    return;
  }

  Serial.println("Dispositivo LIGADO.");

  leituraGas = random(0, 4096);

  Serial.print("Leitura do sensor: ");
  Serial.println(leituraGas);

  if (leituraGas < SEGURO) {
    nivelSeguro();
  }
  else if (leituraGas < ALERTA) {
    nivelAlerta();
  }
  else {
    nivelPerigo();
  }

  if (!interrompido) {
    delay(1500);
  }
}