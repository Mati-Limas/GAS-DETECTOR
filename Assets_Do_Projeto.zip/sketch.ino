#define LED_VERMELHO 2
#define LED_AMARELO 4
#define LED_VERDE 5
#define BUZZER 25
#define SENSOR 34
#define BOTAO 27

//NÍVEIS DE GÁS
#define SEGURO 1500
#define ALERTA 2800

//VARIÁVEIS GLOBAIS
int leituraGas = 0;  //Guarda o valor lido pelo sensor
bool ligado = true;

//Setup
void setup() {
   pinMode(LED_VERMELHO, OUTPUT);
   pinMode(LED_AMARELO, OUTPUT);
   pinMode(LED_VERDE,OUTPUT);
   pinMode(BOTAO, INPUT_PULLUP);

   Serial.begin(115200);
   randomSeed(analogRead(0));
}

//Funções auxiliares
void nivelSeguro() {
  digitalWrite(LED_VERDE,HIGH);
  digitalWrite(LED_AMARELO,LOW);
  digitalWrite(LED_VERMELHO,LOW);
  noTone(BUZZER);
}
void nivelAlerta() {
  digitalWrite(LED_VERDE,LOW);
  digitalWrite(LED_AMARELO,HIGH);
  digitalWrite(LED_VERMELHO,LOW);
  noTone(BUZZER);
}
void nivelPerigo() {
  digitalWrite(LED_VERDE,LOW);
  digitalWrite(LED_AMARELO,LOW);
  digitalWrite(LED_VERMELHO,HIGH);
  for(int i = 0; i < 5; i++){
    tone(BUZZER,1250);
    delay(400);
    noTone(BUZZER);
    delay(280);
  }
}

void desligarTudo() {
  digitalWrite(LED_VERDE,LOW);
  digitalWrite(LED_AMARELO,LOW);
  digitalWrite(LED_VERMELHO,LOW);
  noTone(BUZZER);
}
//LOOP PRINCIPAL
void loop() {
  
  Serial.println(digitalRead(BOTAO)); // 1 significa ta ligado, 0 desligado 👍

  if (digitalRead(BOTAO) == LOW) {
    ligado = !ligado;     //inverte o estado (ligado-Desligado)
    desligarTudo();
    delay(400);           //evita leituras duplas
  }

//se estiver desligado
  if (!ligado) {
    while (digitalRead(BOTAO) != LOW) {

    }
    delay(400);
    ligado = true;      
  }

  leituraGas = random(0, 4096);  //Lê o valor do ADC

  //Imprime no monitor para acompanhar os valores
  Serial.print("Leitura do sensor:");
  Serial.println(leituraGas);

  //define o nível
  if (leituraGas < SEGURO) {
    nivelSeguro();
  }
  else if (leituraGas < ALERTA) {
    nivelAlerta();
  }
  else {
    nivelPerigo();
  }

  delay(500);
}